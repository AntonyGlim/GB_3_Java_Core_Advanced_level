package lesson_7_NetworkChat_part_1.methodicalInstruction;

/**
 * Класс предназначен для хранения констант соединения
 */
public abstract class Constants {
    public static final int PORT = 8440;
    public static final String IPADRESS = "localhost";
}
