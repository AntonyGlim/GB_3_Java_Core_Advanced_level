package lesson_7_NetworkChat_part_1.methodicalInstruction.MainClient;

public class MainClass {
    public static void main(String[] args) {
        new MyWindow();
    }
}
