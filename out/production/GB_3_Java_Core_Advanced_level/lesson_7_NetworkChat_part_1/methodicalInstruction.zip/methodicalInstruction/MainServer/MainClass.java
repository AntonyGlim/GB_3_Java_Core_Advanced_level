package lesson_7_NetworkChat_part_1.methodicalInstruction.MainServer;

public class MainClass {
    public static void main(String[] args) {

        new MyServer();

    }
}
